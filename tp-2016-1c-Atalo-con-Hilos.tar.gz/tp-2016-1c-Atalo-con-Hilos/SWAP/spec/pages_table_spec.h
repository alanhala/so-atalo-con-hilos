#ifndef PAGES_TABLE_SPEC_H
#define PAGES_TABLE_SPEC_H

	#include "../pages_table.h"
	#include "CUnit/Basic.h"

	int pages_table_spec();
	void assigns_rigth_pid();
	void assigns_right_pages();
	void assigns_rigth_location();

#endif
