#include "swap_spec.h"
#include "pages_table_spec.h"
#include "simulacion_de_umc.h"

void run_specs() {
	swap_spec();
	pages_table_spec();
	simulacion_de_umc();
}
