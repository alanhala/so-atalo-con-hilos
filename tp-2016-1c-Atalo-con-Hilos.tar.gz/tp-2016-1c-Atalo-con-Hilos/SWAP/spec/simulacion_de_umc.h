/*
 * simulacion_de_umc.h
 *
 *  Created on: 1/6/2016
 *      Author: utnso
 */

#ifndef SPEC_SIMULACION_DE_UMC_H_
#define SPEC_SIMULACION_DE_UMC_H_

simulacion_de_umc();


#endif /* SPEC_SIMULACION_DE_UMC_H_ */
