/*
 * simulacion.h
 *
 *  Created on: 4/6/2016
 *      Author: utnso
 */

#ifndef TEST_SIMULACION_H_
#define TEST_SIMULACION_H_

int correr_simulacion();


#endif /* TEST_SIMULACION_H_ */
