/*
 * test.h
 *
 *  Created on: 6/5/2016
 *      Author: utnso
 */

int correrTest();
void cargar_archivo_configuracion_umc();
void cargo_programa_pid_100();
void asigno_frame_2_a_la_pagina_5();
void no_esta_presente_frame_2_en_pagina_4();
void escribir_hola_en_frame_0();
void escribir_hola_en_frame_3_offset_5();
void crear_50_frames_de_memoria_principal();
void eliminar_programa_pid_2_sin_ningun_frame_asignado();
void cargar_programa_sin_asignar_frames();
void escribo_pagina_2_de_un_programa();


void cargar_archivo_ansisop_test();
char * cargar_ansisop();



//Tests de Newton - serializacion y protocolo

void valido_conexion();
