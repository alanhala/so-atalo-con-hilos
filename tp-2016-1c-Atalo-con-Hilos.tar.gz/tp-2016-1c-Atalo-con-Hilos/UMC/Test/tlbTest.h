/*
 * tlbTest.h
 *
 *  Created on: 1/6/2016
 *      Author: utnso
 */

#ifndef TLBTEST_H_
#define TLBTEST_H_

int correr_test_tlb();

#endif /* TLBTEST_H_ */
