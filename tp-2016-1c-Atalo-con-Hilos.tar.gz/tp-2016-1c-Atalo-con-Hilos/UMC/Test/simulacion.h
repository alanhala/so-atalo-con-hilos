/*
 * simulacion.h
 *
 *  Created on: 24/5/2016
 *      Author: utnso
 */

#ifndef TEST_SIMULACION_H_
#define TEST_SIMULACION_H_

int simulaciones();

#endif /* TEST_SIMULACION_H_ */
